package net.apispark.webapi.resource;

public interface ContactListResource {

    /**
     * Loads a list of Contact.
     *
     * @return  {@link net.apispark.webapi.representation.ContactList} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Get
    net.apispark.webapi.representation.ContactList getContacts();

    /**
     * Adds a Contact.
     *
     * @return  {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Post
    net.apispark.webapi.representation.Contact postContacts(net.apispark.webapi.representation.Contact bean);

}