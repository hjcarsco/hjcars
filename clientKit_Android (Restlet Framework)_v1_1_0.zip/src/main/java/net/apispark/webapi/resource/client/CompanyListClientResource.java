package net.apispark.webapi.resource.client;

import net.apispark.webapi.resource.client.QueryParameterHelper;


public class CompanyListClientResource {

    private final net.apispark.webapi.security.SecurityRuntimeConfigurator securityRuntimeConfigurator;

    private final java.lang.String absolutePath;

    /**
     * Constructor.
     * 
     * @param config
     *            Gathers configuration of the resource URI and security. 
     */
    public CompanyListClientResource(net.apispark.webapi.Config config) {
        this.securityRuntimeConfigurator = config.getSecurityConfig().getSecurityRuntimeConfigurator();
        this.absolutePath = config.getBasePath() + "/companies/";
    }

    /**
     * Loads a list of Company.
     * 
     * @param sort
     *            Order in which to retrieve the results. Multiple sort criteria can be passed. Example: sort=age ASC,height DESC
     * @param page
     *            Number of the page to retrieve. Integer value.
     * @param id
     *            Allows to filter the collections of result by the value of field id
     * @param size
     *            Size of the page to retrieve. Integer value
     * @param tags
     *            Allows to filter the collections of result by the value of field tags
     * @param name
     *            Allows to filter the collections of result by the value of field name
     * @return {@link net.apispark.webapi.representation.CompanyList} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.CompanyList getCompanies(java.lang.String sort, java.lang.String page, java.lang.String id, java.lang.String size, java.lang.String tags, java.lang.String name) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        QueryParameterHelper.addQueryParameter(client, "$sort", sort);
        QueryParameterHelper.addQueryParameter(client, "$page", page);
        QueryParameterHelper.addQueryParameter(client, "id", id);
        QueryParameterHelper.addQueryParameter(client, "$size", size);
        QueryParameterHelper.addQueryParameter(client, "tags", tags);
        QueryParameterHelper.addQueryParameter(client, "name", name);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.CompanyListResource.class).getCompanies();
    }

    /**
     * Adds a Company.
     * 
     * @param bean
     *            Parameter "bean"
     * @return {@link net.apispark.webapi.representation.Company} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Company postCompanies(net.apispark.webapi.representation.Company bean) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.CompanyListResource.class).postCompanies(bean);
    }

}
