package net.apispark.webapi.resource.client;

import net.apispark.webapi.resource.client.QueryParameterHelper;


public class ContactListClientResource {

    private final net.apispark.webapi.security.SecurityRuntimeConfigurator securityRuntimeConfigurator;

    private final java.lang.String absolutePath;

    /**
     * Constructor.
     * 
     * @param config
     *            Gathers configuration of the resource URI and security. 
     */
    public ContactListClientResource(net.apispark.webapi.Config config) {
        this.securityRuntimeConfigurator = config.getSecurityConfig().getSecurityRuntimeConfigurator();
        this.absolutePath = config.getBasePath() + "/contacts/";
    }

    /**
     * Loads a list of Contact.
     * 
     * @param lastName
     *            Allows to filter the collections of result by the value of field lastName
     * @param company
     *            Allows to filter the collections of result by the value of field company
     * @param page
     *            Number of the page to retrieve. Integer value.
     * @param birthday
     *            Allows to filter the collections of result by the value of field birthday
     * @param id
     *            Allows to filter the collections of result by the value of field id
     * @param rank
     *            Allows to filter the collections of result by the value of field rank
     * @param size
     *            Size of the page to retrieve. Integer value
     * @param sort
     *            Order in which to retrieve the results. Multiple sort criteria can be passed. Example: sort=age ASC,height DESC
     * @param firstName
     *            Allows to filter the collections of result by the value of field firstName
     * @param active
     *            Allows to filter the collections of result by the value of field active
     * @return {@link net.apispark.webapi.representation.ContactList} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.ContactList getContacts(java.lang.String lastName, java.lang.String company, java.lang.String page, java.lang.String birthday, java.lang.String id, java.lang.String rank, java.lang.String size, java.lang.String sort, java.lang.String firstName, java.lang.String active) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        QueryParameterHelper.addQueryParameter(client, "lastName", lastName);
        QueryParameterHelper.addQueryParameter(client, "company", company);
        QueryParameterHelper.addQueryParameter(client, "$page", page);
        QueryParameterHelper.addQueryParameter(client, "birthday", birthday);
        QueryParameterHelper.addQueryParameter(client, "id", id);
        QueryParameterHelper.addQueryParameter(client, "rank", rank);
        QueryParameterHelper.addQueryParameter(client, "$size", size);
        QueryParameterHelper.addQueryParameter(client, "$sort", sort);
        QueryParameterHelper.addQueryParameter(client, "firstName", firstName);
        QueryParameterHelper.addQueryParameter(client, "active", active);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.ContactListResource.class).getContacts();
    }

    /**
     * Adds a Contact.
     * 
     * @param bean
     *            Parameter "bean"
     * @return {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Contact postContacts(net.apispark.webapi.representation.Contact bean) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.ContactListResource.class).postContacts(bean);
    }

}
