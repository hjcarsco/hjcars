package net.apispark.webapi.resource.client;

import net.apispark.webapi.resource.client.QueryParameterHelper;


public class CompanyClientResource {

    private final net.apispark.webapi.security.SecurityRuntimeConfigurator securityRuntimeConfigurator;

    private java.lang.String companyid;

    private final java.lang.String absolutePath;

    /**
     * Constructor.
     * 
     * @param config
     *            Gathers configuration of the resource URI and security. 
     * @param companyid
     *            Identifier of the Company
     */
    public CompanyClientResource(net.apispark.webapi.Config config, java.lang.String companyid) {
        this.securityRuntimeConfigurator = config.getSecurityConfig().getSecurityRuntimeConfigurator();
        this.companyid = companyid;
        this.absolutePath = config.getBasePath() + "/companies/{companyid}";
    }

    /**
     * Loads a Company.
     * 
     * @return {@link net.apispark.webapi.representation.Company} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Company getCompaniesCompanyid() {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("companyid", this.companyid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.CompanyResource.class).getCompaniesCompanyid();
    }

    /**
     * Stores a Company.
     * 
     * @param bean
     *            Parameter "bean"
     * @return {@link net.apispark.webapi.representation.Company} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Company putCompaniesCompanyid(net.apispark.webapi.representation.Company bean) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("companyid", this.companyid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.CompanyResource.class).putCompaniesCompanyid(bean);
    }

    /**
     * Deletes a Company.
     * 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public void deleteCompaniesCompanyid() {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("companyid", this.companyid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        client.wrap(net.apispark.webapi.resource.CompanyResource.class).deleteCompaniesCompanyid();
    }

}
