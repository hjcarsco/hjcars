package net.apispark.webapi.resource;

public interface CompanyListResource {

    /**
     * Loads a list of Company.
     *
     * @return  {@link net.apispark.webapi.representation.CompanyList} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Get
    net.apispark.webapi.representation.CompanyList getCompanies();

    /**
     * Adds a Company.
     *
     * @return  {@link net.apispark.webapi.representation.Company} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Post
    net.apispark.webapi.representation.Company postCompanies(net.apispark.webapi.representation.Company bean);

}