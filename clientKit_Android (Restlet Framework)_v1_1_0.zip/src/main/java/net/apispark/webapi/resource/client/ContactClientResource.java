package net.apispark.webapi.resource.client;

import net.apispark.webapi.resource.client.QueryParameterHelper;


public class ContactClientResource {

    private final net.apispark.webapi.security.SecurityRuntimeConfigurator securityRuntimeConfigurator;

    private java.lang.String contactid;

    private final java.lang.String absolutePath;

    /**
     * Constructor.
     * 
     * @param config
     *            Gathers configuration of the resource URI and security. 
     * @param contactid
     *            Identifier of the Contact
     */
    public ContactClientResource(net.apispark.webapi.Config config, java.lang.String contactid) {
        this.securityRuntimeConfigurator = config.getSecurityConfig().getSecurityRuntimeConfigurator();
        this.contactid = contactid;
        this.absolutePath = config.getBasePath() + "/contacts/{contactid}";
    }

    /**
     * Loads a Contact.
     * 
     * @return {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Contact getContactsContactid() {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("contactid", this.contactid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.ContactResource.class).getContactsContactid();
    }

    /**
     * Stores a Contact.
     * 
     * @param bean
     *            Parameter "bean"
     * @return {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public net.apispark.webapi.representation.Contact putContactsContactid(net.apispark.webapi.representation.Contact bean) {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("contactid", this.contactid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        return client.wrap(net.apispark.webapi.resource.ContactResource.class).putContactsContactid(bean);
    }

    /**
     * Deletes a Contact.
     * 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    public void deleteContactsContactid() {
        org.restlet.resource.ClientResource client = new org.restlet.resource.ClientResource(absolutePath);
        client.setAttribute("contactid", this.contactid);
        securityRuntimeConfigurator.accept(net.apispark.webapi.security.authenticators.defined.HTTP_BASICAuthenticator.class).configure(client);

        client.wrap(net.apispark.webapi.resource.ContactResource.class).deleteContactsContactid();
    }

}
