package net.apispark.webapi.resource;

public interface ContactResource {

    /**
     * Loads a Contact.
     *
     * @return  {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Get
    net.apispark.webapi.representation.Contact getContactsContactid();

    /**
     * Stores a Contact.
     *
     * @return  {@link net.apispark.webapi.representation.Contact} 
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Put
    net.apispark.webapi.representation.Contact putContactsContactid(net.apispark.webapi.representation.Contact bean);

    /**
     * Deletes a Contact.
     *
     * @throws org.restlet.resource.ResourceException if the call to the API fails
     */
    @org.restlet.resource.Delete
    void deleteContactsContactid();

}