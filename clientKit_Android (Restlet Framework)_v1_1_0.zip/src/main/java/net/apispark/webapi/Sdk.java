package net.apispark.webapi;

/**
 * Entry-point for API calls.
 */
public class Sdk {

    private final net.apispark.webapi.Config config = new net.apispark.webapi.Config();

    public Sdk() {
        org.restlet.engine.Engine.getInstance().getRegisteredConverters().add(new org.restlet.ext.jackson.JacksonConverter());
    }

    /**
     * Returns the SDK configuration.
     */
    public net.apispark.webapi.Config getConfig() {
        return config;
    }

    public net.apispark.webapi.resource.client.CompanyListClientResource companyList() {
        return new net.apispark.webapi.resource.client.CompanyListClientResource(config);
    }

    public net.apispark.webapi.resource.client.CompanyClientResource company(java.lang.String companyid) {
        return new net.apispark.webapi.resource.client.CompanyClientResource(config, companyid);
    }

    public net.apispark.webapi.resource.client.ContactListClientResource contactList() {
        return new net.apispark.webapi.resource.client.ContactListClientResource(config);
    }

    public net.apispark.webapi.resource.client.ContactClientResource contact(java.lang.String contactid) {
        return new net.apispark.webapi.resource.client.ContactClientResource(config, contactid);
    }

}
