package net.apispark.webapi.representation;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
public class Contact implements java.io.Serializable {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String id;

    private java.lang.String firstName;

    private java.lang.String lastName;

    private java.util.Date birthday;

    private java.lang.Boolean active;

    private java.lang.Integer rank;

    private java.lang.String company;

    /**
     * Returns the value of property "id". 
     * Auto-generated primary key field
     */
    public java.lang.String getId() {
        return id;
    }

    /**
     * Updates the value of property "id". 
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }

    /**
     * Returns the value of property "firstName". 
     * 
     */
    public java.lang.String getFirstName() {
        return firstName;
    }

    /**
     * Updates the value of property "firstName". 
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }

    /**
     * Returns the value of property "lastName". 
     * 
     */
    public java.lang.String getLastName() {
        return lastName;
    }

    /**
     * Updates the value of property "lastName". 
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }

    /**
     * Returns the value of property "birthday". 
     * 
     */
    public java.util.Date getBirthday() {
        return birthday;
    }

    /**
     * Updates the value of property "birthday". 
     */
    public void setBirthday(java.util.Date birthday) {
        this.birthday = birthday;
    }

    /**
     * Returns the value of property "active". 
     * 
     */
    public java.lang.Boolean getActive() {
        return active;
    }

    /**
     * Updates the value of property "active". 
     */
    public void setActive(java.lang.Boolean active) {
        this.active = active;
    }

    /**
     * Returns the value of property "rank". 
     * 
     */
    public java.lang.Integer getRank() {
        return rank;
    }

    /**
     * Updates the value of property "rank". 
     */
    public void setRank(java.lang.Integer rank) {
        this.rank = rank;
    }

    /**
     * Returns the value of property "company". 
     * This property is a reference to a Company
     */
    public java.lang.String getCompany() {
        return company;
    }

    /**
     * Updates the value of property "company". 
     */
    public void setCompany(java.lang.String company) {
        this.company = company;
    }

}
